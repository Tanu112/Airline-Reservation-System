package Airline;
import java.util.*;
import java.sql.*;
public class AirlineReservation 
{
    public void welcome()
    {
        int i;
	String[] welcome=new String[]{"WELCOME"};
	String[] welcome2=new String[]{" TO"};
	String[] welcome3=new String[]{" AIRLINE RESERVATION"};
	String[] welcome4=new String[]{" MANAGEMENT"};
        System.out.println("\t\t\t\t********************************************************");
	System.out.print("\n\n\t\t\t\t\t\t       ");
	for(i=0;i<welcome.length;i++)		//To print "WELCOME" and strlen(welcome)=7
	{
		System.out.print(welcome[i]+" ");
	}
	System.out.print("\n\n\t\t\t\t\t\t\t ");
	for(i=0;i<welcome2.length;i++)		//To print "TO" and strlen(welcome2)=2
	{
		System.out.print(welcome2[i]+" ");
	}
	System.out.print("\n\n\t\t\t\t\t\t ");
	for(i=0; i<welcome3.length;i++)		//To print "AIRLINE RESERVATION" and strlen(welcome3)=18
	{
		System.out.print(welcome3[i]+" ");
	}
	System.out.print("\n\n\t\t\t\t\t\t      ");
	for(i=0; i<welcome4.length;i++)		//To print "MANAGEMENT" and strlen(welcome4)=10
	{
		System.out.print(welcome4[i]+" ");
	}
        System.out.println();
        System.out.println("\n\n\t\t\t\t********************************************************");        
    }
    public static void main(String[] args) {
        AirlineReservation book=new AirlineReservation();
        System.out.println("---------------");
        System.out.println("    PANEL");
        System.out.println("---------------");
        System.out.println("1. Passenger ");
        System.out.println("2. Admin");
        System.out.println("---------------");
        System.out.println("Enter your choice : ");
        Scanner input=new Scanner(System.in);
        int choice=input.nextInt();
        switch(choice)
        {
            case 1:
                Passenger pass=new Passenger();
                pass.Reservation();
                break;
            case 2:
                Admin ad=new Admin();
                System.out.println("AdminView");
                ad.UpdateDetails();
                break;
        }
    }
}
class Admin
{
    public void AdminView()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getString(9));
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    public void AddDetails()
    {
        int rate, seat_avail;
        String id, name, source, destination, f_class, start, end, avail_status;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getInt(9)+" "+rs.getString(10));
            Scanner input=new Scanner(System.in);
            System.out.println("Enter Flight Id : ");
            id=input.next();
            System.out.println("Enter Flight Name : ");
            name=input.next();
            System.out.println("Enter Flight Source : ");
            source=input.next();
            System.out.println("Enter Flight Destination : ");
            destination=input.next();
            System.out.println("Enter Flight Class : ");
            f_class=input.next();
            System.out.println("Enter Flight Start Time : ");
            start=input.next();
            System.out.println("Enter Flight End Time : ");
            end=input.next();
            System.out.println("Enter Flight Rate : ");
            rate=input.nextInt();
            System.out.println("Enter Flight Seat Availability : ");
            seat_avail=input.nextInt();
            System.out.println("Enter Flight Availability Status : ");
            avail_status=input.next();            
            stmt.executeUpdate("insert into flightdetails (Flight_Id, Flight_Name, Flight_Source, Flight_Destination, Flight_Class, Start_Time, End_Time, Flight_Rate, Seat_Availability, Status) values('"+id+"','"+name+"','"+source+"','"+destination+"','"+f_class+"','"+start+"','"+end+"',"+rate+","+seat_avail+",'"+avail_status+"')");
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    }
    public void UpdateDetails()
    {
        int rate, seat_avail,uch;
        String id, name, source, destination, f_class, start, end, avail_status;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            Scanner input=new Scanner(System.in);
            ResultSet rs=stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getInt(9)+" "+rs.getString(10));
            System.out.println("Enter Flight Id : ");
            id=input.next();
            System.out.println("Enter Flight Source : ");
            source=input.next();
            System.out.println("Enter Flight Destination : ");
            destination=input.next();
            System.out.println("Enter Flight Class : ");
            f_class=input.next();
            System.out.println("Enter Flight Start Time : ");
            start=input.next();
            System.out.println("Enter Flight End Time : ");
            end=input.next();
            System.out.println("Enter Flight Rate : ");
            rate=input.nextInt();
            System.out.println("Enter Flight Seat Availability : ");
            seat_avail=input.nextInt();
            System.out.println("Enter Flight Availability Status : ");
            avail_status=input.next();  
            stmt.executeUpdate("update flightdetails set Flight_Source='"+source+"',Flight_Destination='"+destination+"',Flight_Class='"+f_class+"', Start_Time='"+start+"', End_Time='"+end+"', Flight_Rate='"+rate+"', Seat_Availability='"+seat_avail+"',Status='"+avail_status+"' where Flight_Id='"+id+"'");
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    }
    public void PassengerList()
    {
        //changing of table to passenger
        int rate, seat_avail;
        String id, name, source, destination, f_class, start, end, avail_status;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getInt(9)+" "+rs.getString(10));
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    }
    public void CancellationList()
    {
        //changing of table to passenger
        int rate, seat_avail;
        String id, name, source, destination, f_class, start, end, avail_status;
        try
        {
            //changing of table to cancellation
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getInt(9)+" "+rs.getString(10));
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    }
}
class Passenger
{
    public void ViewDetails()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getString(9));
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }  
    }
    public void Reservation()
    {
        int phone,seat;
        String name, email, f_id, t_date;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            Scanner input=new Scanner(System.in);            
            System.out.println("Enter your name : ");
            name=input.next();
            System.out.println("Enter your email-id : ");
            email=input.next();
            System.out.println("Enter your phone number : ");
            phone=input.nextInt();
            System.out.println("Enter travelling date for booking : ");
            t_date=input.next();
            ResultSet rs=stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getInt(9)+" "+rs.getString(10));
            con.close();
            System.out.println("Enter Flight Id : ");
            f_id=input.next();
            System.out.println("Enter required number of seats : ");
            seat=input.nextInt();
            Class.forName("com.mysql.jdbc.Driver");
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt1=con1.createStatement();
            ResultSet rs1 = stmt1.executeQuery("select * from flightdetails");
            String f_name=rs1.getString("Flight_Name");
            String f_source=rs1.getString("Flight_Source");
            String f_destination=rs1.getString("Flight_Destination");
            String f_class=rs1.getString("Flight_Class");
            String f_start=rs1.getString("Start_Time");
            String f_end=rs1.getString("End_Time");
            int seat_avail=rs1.getInt("Seat_Availability");
            String stat=rs1.getString("Status");
            int rate=rs1.getInt("Flight_Rate");
            if(seat>seat_avail && seat_avail==0)
            {
                System.out.println("Seat Unavailable !!!");
            }
            else
            {
                if(stat=="Available")
                {
                    int amount=rate*seat;
                    Random random = new Random();  
                    int id=random.nextInt(1000);
                    System.out.println("Your passenger id is "+id);
                    Statement stmt2=con.createStatement();                                      
                    stmt2.executeUpdate("insert into passenger(P_Id, P_Name, P_Email, P_Phone, P_FlightId, P_Seats, P_Source, P_Destination, P_start, P_End, P_Class, P_bookTime, P_bookDate, P_TravelDate, Amount) values('"+id+"','"+name+"','"+email+"','"+phone+"','"+f_id+"',"+seat+",'"+f_source+"','"+f_destination+"','"+f_start+"','"+f_end+"',"+f_class+","+java.time.LocalDate.now()+",'"+java.time.LocalTime.now()+"','"+t_date+"',"+amount+")");
                    System.out.println("Your ticket is booked !");
                }
                else
                {
                    System.out.println("Flight Unavailable!!!");
                }
            }
            con1.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    }
    public void Cancel()
    {
        int rate, seat_avail,uch;
        String id, name, source, destination, f_class, start, end, avail_status;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","");
            Statement stmt = con.createStatement();
            Scanner input=new Scanner(System.in);
            ResultSet rs=stmt.executeQuery("select * from flightdetails");
            while(rs.next())
                System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getInt(8)+" "+rs.getInt(9)+" "+rs.getString(10));
            System.out.println("Enter Flight Id : ");
            id=input.next();
            System.out.println("Enter Flight Source : ");
            source=input.next();
            System.out.println("Enter Flight Destination : ");
            destination=input.next();
            System.out.println("Enter Flight Class : ");
            f_class=input.next();
            System.out.println("Enter Flight Start Time : ");
            start=input.next();
            System.out.println("Enter Flight End Time : ");
            end=input.next();
            System.out.println("Enter Flight Rate : ");
            rate=input.nextInt();
            System.out.println("Enter Flight Seat Availability : ");
            seat_avail=input.nextInt();
            System.out.println("Enter Flight Availability Status : ");
            avail_status=input.next();  
            stmt.executeUpdate("update flightdetails set Flight_Source='"+source+"',Flight_Destination='"+destination+"',Flight_Class='"+f_class+"', Start_Time='"+start+"', End_Time='"+end+"', Flight_Rate='"+rate+"', Seat_Availability='"+seat_avail+"',Status='"+avail_status+"' where Flight_Id='"+id+"'");
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    }
}


/*package airlinereservation;
import java.util.Scanner;
import java.sql.*;
public class AirlineReservation 
{
    
    public void PassengerMenu()
    {
        int choice=0;
        Scanner input=new Scanner(System.in);
        while(choice<5)
        {
            System.out.println("\n\n\t\t\t\t********************************************************");
            System.out.print("\t\t\t\t\t\tAIRLINE RESERVATION MANAGEMENT");
            System.out.print("\n\t\t\t\t********************************************************");
            System.out.print("\n\t\t\t\t\t\t1. View All Available airlines");
            System.out.print("\n\t\t\t\t--------------------------------------------------------");
            System.out.print("\n\t\t\t\t\t\t2. Reserve A Ticket");
            System.out.print("\n\t\t\t\t--------------------------------------------------------");
            System.out.print("\n\t\t\t\t\t\t3. Cancel Reservation");
            System.out.print("\n\t\t\t\t--------------------------------------------------------");
            System.out.print("\n\t\t\t\t\t\t4. Exit");
            System.out.print("\n\t\t\t\t********************************************************");
            System.out.print("\n\n\t\t\t\tEnter your choice : ");
            choice=input.nextInt();        
            switch(choice)
            {
                case 1:
                    AirlineView();
                    break;
                case 2:
                    AirlineReserve();
                    break;
                case 3:
                    AirlineCancel();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice....");
            }
        }
    }
    public void AirlineView()
    {
        //Viewing airline details from database table
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL","root","root");
            
            System.out.println("Database connected successfully");    
            Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery("select * from ViewAirline");
                while(rs.next())
                {
                    System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
                }
        }
        catch(Exception e)
        { 
            System.out.println(e);
        }  
    }
    public void AirlineReserve()
    {
        String choice, user;
        int numseats, coach, airclass, airnum;
        //storing the below data in the database table
        Scanner input=new Scanner(System.in);
        System.out.println("Enter username : ");
        user=input.nextLine();
        System.out.println("Enter number of seats : ");
        numseats=input.nextInt();
        System.out.println("Airline Coach : \n\t1.A/C\n\t2.Non A/C");
        System.out.println("Enter Coach : ");
        coach=input.nextInt();
        System.out.println("Airline Class : \n\t1.Business Class\n\t2.Second Class\n\t3.Third Class");
        System.out.println("Enter Class : ");
        airclass=input.nextInt();
        //Viewing airline details from database table
        System.out.println("Enter airline number : ");
        airnum=input.nextInt();
        //Generating unique id
        //Printing airline ticket
        System.out.println("Confirmation of ticket (Y-yes,N-no)");
        choice=input.nextLine();
        switch(choice)
        {
            case "Y":
                System.out.println("Reservation done successfully!");
                //sending email if possible
            case "N":
                //if no, main menu
        }
    }
    public void AirlineCancel()
    {
        System.out.println("Enter unique ID : ");
        System.out.println("Enter username : ");
        System.out.println("Enter airline number : ");
        //copying the data and storing it in another table and deleting the data in the existing table
    }
    
}
*/

